RACHEL HOME APPLIANCES & FASHION — STARTER WEBSITE

Upload index.html to the LAST GitHub repository you selected:
1. Open that repository.
2. Choose Add file → Upload files.
3. Select index.html and commit/save the changes.
4. Open Settings → Pages.
5. Under Build and deployment choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish; copy the URL shown there.

This is a static starter storefront with working category filters, search and WhatsApp enquiry buttons. The cards are starter category listings, not a live inventory or checkout. Add actual product photos, descriptions and prices before promoting products. Online payment processing needs a supported provider and account setup. Google Search and Google Maps listing setup are separate steps; publication does not guarantee immediate indexing or a Maps listing.
